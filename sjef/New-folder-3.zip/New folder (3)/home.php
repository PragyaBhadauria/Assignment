<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
	 width: 100%;
	 background-color:white;
}
table, th {
    border: 2px solid black;
}
table {
    background-color: #E67855;
    border-collapse: collapse;
    width: 100%;
}
div.container {
    width: 100%;
    border: 1px solid gray;
}

header, footer {
    padding: 1em;
    color: white;
    background-color: #0E6BBD;
    clear: left;
    text-align: left;
}

.right {
    position: absolute;
    right: 0px;
	margin-top:100px;
    width: 100px;
    border: 3px solid #73AD21;
    padding: 100px;
     
}
div.notice {
    background-color: black;
    color: white;
    margin-top:0px;
    padding: 15px;
}

</style>
</head>
<body>

<div class="container">

<header>
<img src="C:\Users\megalh\Desktop\cs\nit-calicut.jpg" alt="Mountain View" style="width:100px;height:102px;">

   <h1>Silver Jubilee Endowment Trust </h1>
   <h3>National Institute of Technology Calicut</h3>
</header>

<table>
  <tr>
<th><h2><a href="home.php">Home</a></h2></th>
<th><h2><a href="sch.php">Scholarship</a></h2></th>
<th><h2><a href="trusties.php">Trusties</a></h2></th>
<th><h2><a href="about_us.php">About Us</a></h2></th>
<th><h2><a href="FAQ.php">FAQ</a></h2></th>
<th><h2><a href="Gallery.php">Gallery</a></h2></th>
<th><h2><a href="contact.php">Contact us</a></h2></th>
</div>

<div class="right">
<div class="notice">
<h3> Important Notice </h3></div>
   
</div>


</body>
</html>

